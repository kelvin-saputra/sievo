"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Trash2, ArrowDownUp, Plus, Filter, ChevronDown } from "lucide-react";
import useProposal from "@/hooks/use-proposals";
import { ProposalStatusEnum } from "@/models/enums";
import PageHeader from "@/components/commons/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { proposalColumns } from "./columns";

export default function ViewAllProposal() {
  const { proposals, loading, fetchAllProposals } = useProposal();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    fetchAllProposals();
  }, [fetchAllProposals]);

  const getStatusBadge = (status: keyof typeof ProposalStatusEnum.enum) => {
    switch (status) {
      case "APPROVED":
        return <Badge className="bg-green-500">{status}</Badge>;
      case "ON_REVIEW":
      case "SENT":
      case "ON_CONTACT":
      case "INTERESTED":
        return <Badge className="bg-orange-500">{status}</Badge>;
      case "REJECTED":
        return <Badge className="bg-gray-500">{status}</Badge>;
      case "DRAFT":
        return <Badge className="bg-blue-500">{status}</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const totalPages = Math.ceil(proposals.length / itemsPerPage);
  const paginatedProposals = proposals.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div>
      {/* Header Section */}
      <PageHeader
        title="Proposal Overview"
        breadcrumbs={[{ label: "Proposal", href: "/proposal" }]}
      />

      {/* <div className="mb-6">
        <AddProposalModal onAddProposal={handleAddProposal} />
      </div> */}


      <div className="mb-8 p-6 border rounded-lg shadow-lg bg-super-white">

        {loading ? (
          <Skeleton className="h-24 w-full mb-4 rounded-lg bg-gray-300" />
        ) : (
          <InventoryTable
            columns={}
            data={inventories}
          />
        )}
        </div>
    </div>
  );
}
